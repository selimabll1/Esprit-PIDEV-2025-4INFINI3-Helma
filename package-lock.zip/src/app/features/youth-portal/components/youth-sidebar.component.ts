import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { SessionService } from '../../../core/services/session.service';

type SidebarItem = {
  label: string;
  route: string;
  exact?: boolean;
  icon: string;
};

type SidebarSection = {
  title: string;
  items: SidebarItem[];
};

@Component({
  selector: 'app-youth-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <aside class="sidebar" [class.sidebar--collapsed]="collapsed">
      <div class="sidebar__frame">
        <div class="gold-leaf gold-leaf--top"></div>
        <div class="gold-leaf gold-leaf--bottom"></div>

        <div class="sidebar__top">
          <a class="sidebar__brand" routerLink="/">
            <span class="sidebar__logo-shell">
              <img
                src="logo/helma-logo.png"
                alt="Helma logo"
                class="sidebar__brand-logo"
              />
            </span>

            <div class="sidebar__brand-copy">
              <span class="sidebar__brand-name">Helma</span>
              <span class="sidebar__brand-role">Youth Portal</span>
            </div>
          </a>

          <button
            type="button"
            class="sidebar__collapse-btn"
            (click)="toggleCollapse()"
            [attr.aria-label]="
              collapsed ? 'Expand sidebar' : 'Collapse sidebar'
            "
            [title]="collapsed ? 'Expand sidebar' : 'Collapse sidebar'"
          >
            <span>{{ collapsed ? '›' : '‹' }}</span>
          </button>
        </div>

        <nav class="sidebar__nav" aria-label="Youth portal navigation">
          <section class="sidebar__section" *ngFor="let section of sections">
            <p class="sidebar__section-title">{{ section.title }}</p>

            <div class="sidebar__links">
              <a
                *ngFor="let item of section.items"
                class="sidebar__link"
                [routerLink]="item.route"
                routerLinkActive="active"
                [routerLinkActiveOptions]="{ exact: item.exact ?? false }"
                [title]="collapsed ? item.label : null"
              >
                <span class="sidebar__link-icon">{{ item.icon }}</span>
                <span class="sidebar__link-label">{{ item.label }}</span>
              </a>
            </div>
          </section>
        </nav>

        <div class="sidebar__account">
          <div class="sidebar__account-main">
            <div class="sidebar__avatar">{{ initials() }}</div>

            <div class="sidebar__account-copy">
              <strong>{{ userName() }}</strong>
              <small>{{ email() || 'Signed in user' }}</small>
            </div>
          </div>

          <div class="sidebar__account-actions">
            <a
              class="sidebar__icon-btn"
              routerLink="/settings"
              aria-label="Settings"
              title="Settings"
            >
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path
                  d="M19.14 12.94c.04-.31.06-.62.06-.94s-.02-.63-.06-.94l2.03-1.58a.5.5 0 0 0 .12-.64l-1.92-3.32a.5.5 0 0 0-.6-.22l-2.39.96a7.2 7.2 0 0 0-1.63-.94l-.36-2.54a.5.5 0 0 0-.49-.42h-3.84a.5.5 0 0 0-.49.42l-.36 2.54c-.57.23-1.12.55-1.63.94l-2.39-.96a.5.5 0 0 0-.6.22L2.7 8.84a.5.5 0 0 0 .12.64l2.03 1.58c-.04.31-.06.62-.06.94s.02.63.06.94L2.82 14.52a.5.5 0 0 0-.12.64l1.92 3.32a.5.5 0 0 0 .6.22l2.39-.96c.51.39 1.06.71 1.63.94l.36 2.54a.5.5 0 0 0 .49.42h3.84a.5.5 0 0 0 .49-.42l.36-2.54c.57-.23 1.12-.55 1.63-.94l2.39.96a.5.5 0 0 0 .6-.22l1.92-3.32a.5.5 0 0 0-.12-.64l-2.03-1.58ZM12 15.5A3.5 3.5 0 1 1 12 8.5a3.5 3.5 0 0 1 0 7Z"
                />
              </svg>
            </a>

            <button
              type="button"
              class="sidebar__icon-btn sidebar__icon-btn--danger"
              (click)="logout()"
              aria-label="Logout"
              title="Logout"
            >
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path
                  d="M10 17v-2h5V9h-5V7h5a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2h-5Zm-1.41-1.59L5 11.83l3.59-3.58L10 9.66 8.83 10.83H14v2H8.83L10 14l-1.41 1.41ZM19 19V5h2v14h-2Z"
                />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </aside>
  `,
  styles: [
    `
      :host {
        display: block;
        height: 100%;
      }

      .sidebar {
        width: 292px;
        height: 100vh;
        min-height: 100vh;
        transition: width 0.22s ease;
      }

      .sidebar--collapsed {
        width: 92px;
      }

      .sidebar__frame {
        position: relative;
        overflow: hidden;
        height: 100vh;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        gap: 14px;
        padding: 14px;
        background:
          radial-gradient(
            circle at 20% 0%,
            rgba(247, 215, 124, 0.34),
            transparent 28%
          ),
          radial-gradient(
            circle at 95% 18%,
            rgba(212, 166, 42, 0.18),
            transparent 30%
          ),
          linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.99),
            rgba(255, 250, 239, 0.98)
          );
        border-right: 1px solid rgba(212, 166, 42, 0.16);
        box-shadow: 10px 0 32px rgba(15, 23, 42, 0.05);
        box-sizing: border-box;
      }

      .gold-leaf {
        position: absolute;
        width: 190px;
        height: 190px;
        pointer-events: none;
        opacity: 0.28;
        background:
          radial-gradient(
            ellipse at center,
            rgba(184, 130, 38, 0.36) 0 24%,
            transparent 25%
          ),
          radial-gradient(
            ellipse at center,
            rgba(218, 165, 62, 0.3) 0 24%,
            transparent 25%
          ),
          radial-gradient(
            ellipse at center,
            rgba(157, 111, 28, 0.2) 0 24%,
            transparent 25%
          );
        background-size:
          42px 72px,
          54px 86px,
          38px 66px;
        background-position:
          0 0,
          48px 22px,
          96px 2px;
        filter: blur(0.1px);
      }

      .gold-leaf--top {
        right: -74px;
        top: -64px;
        transform: rotate(-28deg);
      }

      .gold-leaf--bottom {
        left: -78px;
        bottom: 92px;
        transform: rotate(138deg);
        opacity: 0.18;
      }

      .sidebar__top,
      .sidebar__brand,
      .sidebar__nav,
      .sidebar__account {
        position: relative;
        z-index: 1;
      }

      .sidebar__top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding-bottom: 12px;
        border-bottom: 1px solid rgba(212, 166, 42, 0.18);
      }

      .sidebar__brand {
        min-width: 0;
        display: flex;
        align-items: center;
        gap: 10px;
        text-decoration: none;
        flex: 1;
      }

      .sidebar__logo-shell {
        width: 48px;
        height: 48px;
        display: grid;
        place-items: center;
        border-radius: 18px;
        flex-shrink: 0;
        background: linear-gradient(180deg, #fff7df, #ffffff);
        border: 1px solid rgba(212, 166, 42, 0.24);
        box-shadow: 0 12px 22px rgba(212, 166, 42, 0.12);
      }

      .sidebar__brand-logo {
        width: 38px;
        height: 38px;
        object-fit: contain;
        flex-shrink: 0;
      }

      .sidebar__brand-copy {
        display: flex;
        flex-direction: column;
        min-width: 0;
        opacity: 1;
        transform: translateX(0);
        transition:
          opacity 0.16s ease,
          transform 0.16s ease,
          width 0.16s ease;
      }

      .sidebar__brand-name {
        font-size: 1.25rem;
        font-weight: 900;
        line-height: 1;
        letter-spacing: -0.04em;
        color: var(--helma-teal);
      }

      .sidebar__brand-role {
        margin-top: 5px;
        font-size: 11px;
        font-weight: 900;
        color: #a47814;
        text-transform: uppercase;
        letter-spacing: 0.09em;
        white-space: nowrap;
      }

      .sidebar__collapse-btn {
        width: 38px;
        height: 38px;
        display: grid;
        place-items: center;
        border: 1px solid rgba(212, 166, 42, 0.28);
        border-radius: 14px;
        background: linear-gradient(180deg, #fff8e3, #ffffff);
        color: #8d6a08;
        cursor: pointer;
        box-shadow: 0 10px 18px rgba(212, 166, 42, 0.1);
        transition:
          transform 0.18s ease,
          box-shadow 0.18s ease,
          background 0.18s ease;
        flex-shrink: 0;
      }

      .sidebar__collapse-btn span {
        display: inline-block;
        font-size: 1.7rem;
        line-height: 1;
        transform: translateY(-1px);
      }

      .sidebar__collapse-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 14px 24px rgba(212, 166, 42, 0.16);
        background: linear-gradient(180deg, #f7d774, #fff8e3);
      }

      .sidebar__nav {
        display: grid;
        gap: 13px;
        align-content: start;
        flex: 1;
        min-height: 0;
        overflow-y: auto;
        padding-right: 2px;
        scrollbar-width: thin;
      }

      .sidebar__nav::-webkit-scrollbar {
        width: 5px;
      }

      .sidebar__nav::-webkit-scrollbar-thumb {
        background: rgba(212, 166, 42, 0.35);
        border-radius: 999px;
      }

      .sidebar__section {
        display: grid;
        gap: 7px;
      }

      .sidebar__section-title {
        margin: 0;
        padding: 0 7px;
        font-size: 10px;
        font-weight: 900;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        color: #9a8a6e;
        transition: opacity 0.16s ease;
      }

      .sidebar__links {
        display: grid;
        gap: 7px;
      }

      .sidebar__link {
        min-height: 46px;
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 0 13px;
        border-radius: 18px;
        border: 1px solid rgba(255, 255, 255, 0.65);
        background: rgba(255, 255, 255, 0.72);
        color: var(--color-text);
        text-decoration: none;
        font-weight: 800;
        transition:
          transform 0.18s ease,
          background 0.18s ease,
          border-color 0.18s ease,
          box-shadow 0.18s ease,
          color 0.18s ease;
        backdrop-filter: blur(8px);
      }

      .sidebar__link-icon {
        width: 30px;
        height: 30px;
        display: grid;
        place-items: center;
        border-radius: 12px;
        flex-shrink: 0;
        background: rgba(212, 166, 42, 0.11);
        font-size: 1rem;
        box-shadow: inset 0 0 0 1px rgba(212, 166, 42, 0.12);
        transition:
          background 0.18s ease,
          transform 0.18s ease;
      }

      .sidebar__link-label {
        min-width: 0;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        transition:
          opacity 0.16s ease,
          transform 0.16s ease;
      }

      .sidebar__link:hover {
        background: #ffffff;
        border-color: rgba(212, 166, 42, 0.22);
        box-shadow: 0 12px 22px rgba(15, 23, 42, 0.06);
        transform: translateY(-1px);
      }

      .sidebar__link:hover .sidebar__link-icon {
        transform: scale(1.04);
        background: rgba(212, 166, 42, 0.17);
      }

      .sidebar__link.active {
        background:
          linear-gradient(
            90deg,
            rgba(247, 215, 124, 0.88),
            rgba(255, 255, 255, 0.96)
          ),
          linear-gradient(180deg, #ffffff, #fff8e3);
        border-color: rgba(212, 166, 42, 0.34);
        color: #6f5306;
        box-shadow: 0 14px 28px rgba(212, 166, 42, 0.16);
      }

      .sidebar__link.active .sidebar__link-icon {
        background: rgba(255, 255, 255, 0.74);
        box-shadow:
          inset 0 0 0 1px rgba(212, 166, 42, 0.22),
          0 8px 16px rgba(212, 166, 42, 0.14);
      }

      .sidebar__account {
        margin-top: auto;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 12px;
        border-radius: 24px;
        border: 1px solid rgba(212, 166, 42, 0.2);
        background:
          radial-gradient(
            circle at top right,
            rgba(247, 215, 124, 0.18),
            transparent 38%
          ),
          linear-gradient(180deg, #ffffff, rgba(255, 249, 235, 0.98));
        box-shadow: 0 16px 32px rgba(15, 23, 42, 0.07);
      }

      .sidebar__account-main {
        min-width: 0;
        display: flex;
        align-items: center;
        gap: 10px;
        flex: 1;
      }

      .sidebar__avatar {
        width: 52px;
        height: 52px;
        display: grid;
        place-items: center;
        border-radius: 18px;
        flex-shrink: 0;
        background: linear-gradient(
          180deg,
          var(--helma-teal),
          var(--helma-teal-dark)
        );
        color: #ffffff;
        font-size: 14px;
        font-weight: 900;
        letter-spacing: 0.04em;
        box-shadow: 0 12px 22px rgba(15, 107, 104, 0.16);
      }

      .sidebar__account-copy {
        min-width: 0;
        display: grid;
        gap: 3px;
        transition:
          opacity 0.16s ease,
          transform 0.16s ease;
      }

      .sidebar__account-copy strong {
        font-size: 14px;
        font-weight: 900;
        color: var(--color-text);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .sidebar__account-copy small {
        font-size: 12px;
        color: var(--color-text-muted);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .sidebar__account-actions {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 8px;
        flex-shrink: 0;
      }

      .sidebar__icon-btn {
        width: 40px;
        height: 40px;
        display: inline-grid;
        place-items: center;
        padding: 0;
        border: 1px solid rgba(229, 231, 235, 0.95);
        border-radius: 15px;
        background: #ffffff;
        color: var(--helma-teal);
        cursor: pointer;
        text-decoration: none;
        transition:
          transform 0.18s ease,
          background 0.18s ease,
          border-color 0.18s ease,
          box-shadow 0.18s ease;
      }

      .sidebar__icon-btn svg {
        width: 18px;
        height: 18px;
        fill: currentColor;
      }

      .sidebar__icon-btn:hover {
        transform: translateY(-1px);
        background: var(--helma-teal-soft);
        border-color: rgba(15, 107, 104, 0.16);
        box-shadow: var(--shadow-sm);
      }

      .sidebar__icon-btn--danger {
        color: #cb5b5b;
        background: #fff8f8;
      }

      .sidebar__icon-btn--danger:hover {
        background: #ffecec;
        border-color: rgba(203, 91, 91, 0.15);
      }

      .sidebar--collapsed .sidebar__frame {
        padding: 14px 10px;
        align-items: center;
      }

      .sidebar--collapsed .sidebar__top {
        width: 100%;
        flex-direction: column;
        justify-content: center;
        padding-bottom: 10px;
      }

      .sidebar--collapsed .sidebar__brand {
        justify-content: center;
        flex: none;
      }

      .sidebar--collapsed .sidebar__brand-copy,
      .sidebar--collapsed .sidebar__section-title,
      .sidebar--collapsed .sidebar__link-label,
      .sidebar--collapsed .sidebar__account-copy {
        opacity: 0;
        width: 0;
        max-width: 0;
        overflow: hidden;
        transform: translateX(-6px);
        pointer-events: none;
      }

      .sidebar--collapsed .sidebar__nav,
      .sidebar--collapsed .sidebar__section,
      .sidebar--collapsed .sidebar__links {
        width: 100%;
      }

      .sidebar--collapsed .sidebar__link {
        justify-content: center;
        padding: 0;
      }

      .sidebar--collapsed .sidebar__link-icon {
        width: 38px;
        height: 38px;
        font-size: 1.08rem;
      }

      .sidebar--collapsed .sidebar__account {
        width: 100%;
        padding: 10px;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }

      .sidebar--collapsed .sidebar__account-main {
        justify-content: center;
      }

      .sidebar--collapsed .sidebar__account-actions {
        flex-direction: column;
      }

      .sidebar--collapsed .sidebar__avatar {
        width: 44px;
        height: 44px;
        border-radius: 16px;
        font-size: 12px;
      }

      @media (max-width: 960px) {
        .sidebar,
        .sidebar--collapsed {
          width: 100%;
          height: auto;
          min-height: auto;
        }

        .sidebar__frame {
          height: auto;
          min-height: auto;
          border-right: 0;
          border-bottom: 1px solid rgba(212, 166, 42, 0.2);
          box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
          padding: 12px;
        }

        .sidebar__top {
          padding-bottom: 10px;
        }

        .sidebar__nav {
          display: flex;
          gap: 10px;
          overflow-x: auto;
          padding-bottom: 4px;
        }

        .sidebar__section {
          min-width: max-content;
        }

        .sidebar__section-title {
          display: none;
        }

        .sidebar__links {
          display: flex;
          gap: 8px;
        }

        .sidebar__link {
          min-width: max-content;
          padding: 0 12px;
        }

        .sidebar__account {
          margin-top: 0;
        }

        .sidebar--collapsed .sidebar__frame {
          align-items: stretch;
        }

        .sidebar--collapsed .sidebar__top {
          flex-direction: row;
        }

        .sidebar--collapsed .sidebar__brand-copy,
        .sidebar--collapsed .sidebar__link-label,
        .sidebar--collapsed .sidebar__account-copy {
          opacity: 1;
          width: auto;
          max-width: none;
          transform: none;
          pointer-events: auto;
        }

        .sidebar--collapsed .sidebar__link {
          justify-content: flex-start;
          padding: 0 12px;
        }

        .sidebar--collapsed .sidebar__account-actions {
          flex-direction: row;
        }
      }
    `,
  ],
})
export class YouthSidebarComponent {
  private readonly sessionService = inject(SessionService);
  private readonly router = inject(Router);

  collapsed = false;

  readonly sections: SidebarSection[] = [
    {
      title: 'Overview',
      items: [
        {
          label: 'Dashboard',
          route: '/youth',
          exact: true,
          icon: '⌂',
        },
      ],
    },
    {
      title: 'Financial Tools',
      items: [
        {
          label: 'Savings',
          route: '/youth/savings',
          exact: true,
          icon: '◈',
        },
        {
          label: 'Budgeting',
          route: '/youth/budgeting',
          exact: true,
          icon: '▦',
        },
        {
          label: 'Guidance',
          route: '/youth/guidance',
          exact: true,
          icon: '✦',
        },
      ],
    },
    {
      title: 'Financing',
      items: [
        {
          label: 'Micro-Loans',
          route: '/youth/micro-loans',
          exact: true,
          icon: '◉',
        },
        {
          label: 'Micro-Leasing',
          route: '/youth/micro-leasing',
          exact: true,
          icon: '◇',
        },
      ],
    },
    {
      title: 'Fundraising',
      items: [
        {
          label: 'Crowdfunding Hub',
          route: '/youth/crowdfunding',
          exact: true,
          icon: '☘',
        },
        {
          label: 'My Applications',
          route: '/youth/applications',
          exact: false,
          icon: '▣',
        },
      ],
    },
    {
      title: 'Account',
      items: [
        {
          label: 'Profile',
          route: '/profile',
          exact: true,
          icon: '◌',
        },
        {
          label: 'Support',
          route: '/youth/support',
          exact: true,
          icon: '?',
        },
      ],
    },
  ];

  toggleCollapse(): void {
    this.collapsed = !this.collapsed;
  }

  email(): string | null {
    return this.sessionService.email();
  }

  userName(): string {
    const email = this.email();

    if (!email) {
      return 'Helma User';
    }

    const local = email.split('@')[0]?.trim() ?? '';
    const cleaned = local.replace(/[._-]+/g, ' ').trim();

    if (!cleaned) {
      return 'Helma User';
    }

    return cleaned
      .split(' ')
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase())
      .join(' ');
  }

  initials(): string {
    const parts = this.userName().split(' ').filter(Boolean).slice(0, 2);

    if (!parts.length) {
      return 'HM';
    }

    return parts.map((part) => part[0]!.toUpperCase()).join('');
  }

  logout(): void {
    this.sessionService.clearSession();
    this.router.navigateByUrl('/auth/login');
  }
}
