import { CommonModule } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { catchError, of, timeout } from 'rxjs';
import { CrowdfundingService } from '../../../core/services/crowdfunding.service';
import { SessionService } from '../../../core/services/session.service';


@Component({
  selector: 'app-admin-dashboard-page',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <section class="dashboard-page">
      <div class="debug-card">
        <strong>Admin dashboard loaded</strong>
        <span>Role: {{ currentRole() || 'No role found' }}</span>
      </div>

      <div class="hero-card">
        <div>
          <p class="eyebrow">Overview</p>
          <h2>{{ roleTitle() }}</h2>
          <p>
            Monitor applications, review operations, and payment activity from one portal.
          </p>
        </div>

        <a
          *ngIf="isAdmin()"
          routerLink="/admin/compliance/new"
          class="hero-action"
        >
          Add compliance worker
        </a>
      </div>

      <div class="state-card" *ngIf="loading()">
        Loading dashboard data...
      </div>

      <p class="error-box" *ngIf="error()">{{ error() }}</p>

      <div class="stats-grid">
        <article class="stat-card">
          <span class="icon">🗂️</span>
          <p>Total applications</p>
          <strong>{{ applicationsCount() }}</strong>
        </article>

        <article class="stat-card">
          <span class="icon">⏳</span>
          <p>Submitted</p>
          <strong>{{ submittedCount() }}</strong>
        </article>

        <article class="stat-card">
          <span class="icon">🔎</span>
          <p>Under review</p>
          <strong>{{ reviewCount() }}</strong>
        </article>

        <article class="stat-card">
          <span class="icon">✅</span>
          <p>Approved</p>
          <strong>{{ approvedCount() }}</strong>
        </article>

        <article class="stat-card">
          <span class="icon">💳</span>
          <p>Total payments</p>
          <strong>{{ paymentsCount() }}</strong>
        </article>

        <article class="stat-card">
          <span class="icon">💰</span>
          <p>Succeeded payments</p>
          <strong>{{ succeededPaymentsCount() }}</strong>
        </article>
      </div>

      <div class="panel-grid">
        <section class="panel">
          <div class="panel-head">
            <div>
              <p class="eyebrow">Applications</p>
              <h3>Latest applications</h3>
            </div>

            <a routerLink="/admin/applications">See all</a>
          </div>

          <div class="empty-state" *ngIf="!latestApplications().length">
            No applications available.
          </div>

          <div class="rows" *ngIf="latestApplications().length">
            <a
              *ngFor="let item of latestApplications()"
              class="row"
              [routerLink]="['/admin/applications', item.id]"
            >
              <div>
                <strong>{{ item.businessName || 'Untitled application' }}</strong>
                <span>{{ beautify(item.type) }} · {{ beautify(item.status) }}</span>
              </div>

              <span class="badge">{{ beautify(item.status) }}</span>
            </a>
          </div>
        </section>

        <section class="panel">
          <div class="panel-head">
            <div>
              <p class="eyebrow">Payments</p>
              <h3>Latest payments</h3>
            </div>

            <a routerLink="/admin/payments">See all</a>
          </div>

          <div class="empty-state" *ngIf="!latestPayments().length">
            No payments available.
          </div>

          <div class="rows" *ngIf="latestPayments().length">
            <div *ngFor="let item of latestPayments()" class="row">
              <div>
                <strong>{{ getPaymentName(item) }}</strong>
                <span>{{ item.amount ?? 0 }} {{ item.currency || 'TND' }}</span>
              </div>

              <span class="badge">{{ beautify(item.status) }}</span>
            </div>
          </div>
        </section>
      </div>
    </section>
  `,
  styles: [`
    .dashboard-page {
      display: grid;
      gap: 20px;
    }

    .debug-card,
    .hero-card,
    .stat-card,
    .panel,
    .state-card {
      background: rgba(255,255,255,0.92);
      border: 1px solid rgba(6,42,43,0.08);
      box-shadow: 0 18px 40px rgba(6,42,43,0.08);
    }

    .debug-card {
      display: flex;
      justify-content: space-between;
      gap: 12px;
      padding: 12px 16px;
      border-radius: 16px;
      color: #062a2b;
      font-weight: 800;
    }

    .debug-card span {
      color: #667672;
    }

    .hero-card {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 16px;
      padding: 24px;
      border-radius: 26px;
      background:
        linear-gradient(135deg, rgba(6,42,43,0.96), rgba(11,66,64,0.94)),
        #062a2b;
      color: white;
      position: relative;
      overflow: hidden;
    }

    .hero-card::after {
      content: '';
      position: absolute;
      right: -80px;
      top: -80px;
      width: 220px;
      height: 220px;
      border-radius: 50%;
      background: rgba(243,223,152,0.16);
    }

    .hero-card > * {
      position: relative;
      z-index: 1;
    }

    .eyebrow {
      margin: 0 0 6px;
      color: #b9922f;
      font-size: 0.76rem;
      font-weight: 900;
      letter-spacing: 0.08em;
      text-transform: uppercase;
    }

    .hero-card .eyebrow {
      color: #f3df98;
    }

    .hero-card h2 {
      margin: 0;
      font-size: clamp(1.6rem, 3vw, 2.3rem);
    }

    .hero-card p:not(.eyebrow) {
      margin: 10px 0 0;
      max-width: 640px;
      line-height: 1.6;
      color: rgba(255,255,255,0.76);
    }

    .hero-action {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 46px;
      padding: 0 18px;
      border-radius: 999px;
      background: #f3df98;
      color: #062a2b;
      text-decoration: none;
      font-weight: 900;
      white-space: nowrap;
    }

    .state-card {
      padding: 16px;
      border-radius: 18px;
      color: #5c6b73;
      font-weight: 800;
    }

    .error-box {
      margin: 0;
      padding: 14px 16px;
      border-radius: 16px;
      background: #fff0f0;
      color: #a43a3a;
      font-weight: 800;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(6, minmax(0, 1fr));
      gap: 14px;
    }

    .stat-card {
      padding: 18px;
      border-radius: 22px;
    }

    .icon {
      width: 42px;
      height: 42px;
      display: grid;
      place-items: center;
      border-radius: 14px;
      background: #f6efd6;
      margin-bottom: 12px;
    }

    .stat-card p {
      margin: 0;
      color: #667672;
      font-size: 0.88rem;
      font-weight: 800;
    }

    .stat-card strong {
      display: block;
      margin-top: 8px;
      color: #062a2b;
      font-size: 1.95rem;
    }

    .panel-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 18px;
    }

    .panel {
      border-radius: 24px;
      padding: 20px;
    }

    .panel-head {
      display: flex;
      justify-content: space-between;
      gap: 16px;
      align-items: flex-start;
      margin-bottom: 14px;
    }

    .panel-head h3 {
      margin: 0;
      color: #062a2b;
      font-size: 1.25rem;
    }

    .panel-head a {
      color: #8b6d20;
      text-decoration: none;
      font-weight: 900;
    }

    .empty-state {
      padding: 18px;
      border-radius: 16px;
      background: #f8f5ec;
      color: #697673;
      font-weight: 700;
    }

    .rows {
      display: grid;
      gap: 10px;
    }

    .row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 14px;
      padding: 14px;
      border-radius: 16px;
      background: #faf7ef;
      color: inherit;
      text-decoration: none;
      transition: 0.18s ease;
    }

    a.row:hover {
      background: #f3eedf;
      transform: translateY(-1px);
    }

    .row strong {
      display: block;
      color: #062a2b;
      margin-bottom: 4px;
    }

    .row span {
      color: #687571;
      font-size: 0.84rem;
      font-weight: 700;
    }

    .badge {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 30px;
      padding: 0 10px;
      border-radius: 999px;
      background: #edf1f0;
      color: #40514d;
      font-size: 0.72rem;
      font-weight: 900;
      white-space: nowrap;
    }

    @media (max-width: 1180px) {
      .stats-grid {
        grid-template-columns: repeat(3, minmax(0, 1fr));
      }

      .panel-grid {
        grid-template-columns: 1fr;
      }
    }

    @media (max-width: 720px) {
      .debug-card,
      .hero-card,
      .panel-head,
      .row {
        flex-direction: column;
        align-items: flex-start;
      }

      .stats-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }
    }
  `]
})
export class AdminDashboardPageComponent {
  private readonly crowdfundingService = inject(CrowdfundingService);
  private readonly sessionService = inject(SessionService);

  readonly loading = signal(false);
  readonly error = signal<string | null>(null);

  readonly applications = signal<any[]>([]);
  readonly payments = signal<any[]>([]);

  readonly currentRole = computed(() => this.sessionService.role());
  readonly isAdmin = computed(() => this.sessionService.role() === 'ADMIN');

  readonly roleTitle = computed(() => {
    const role = this.sessionService.role();

    if (role === 'ADMIN') {
      return 'Admin overview';
    }

    if (role === 'COMPLIANCE') {
      return 'Compliance overview';
    }

    return 'Back office overview';
  });

  readonly applicationsCount = computed(() => this.applications().length);
  readonly paymentsCount = computed(() => this.payments().length);

  readonly submittedCount = computed(() =>
    this.applications().filter((item) => this.normalize(item?.status) === 'SUBMITTED').length
  );

  readonly reviewCount = computed(() =>
    this.applications().filter((item) => this.normalize(item?.status) === 'UNDER_REVIEW').length
  );

  readonly approvedCount = computed(() =>
    this.applications().filter((item) => this.normalize(item?.status) === 'APPROVED').length
  );

  readonly succeededPaymentsCount = computed(() =>
    this.payments().filter((item) => this.normalize(item?.status) === 'SUCCEEDED').length
  );

  readonly latestApplications = computed(() =>
    [...this.applications()]
      .sort((a, b) => this.toDate(b?.updatedAt) - this.toDate(a?.updatedAt))
      .slice(0, 6)
  );

  readonly latestPayments = computed(() =>
    [...this.payments()]
      .sort((a, b) => this.toDate(b?.updatedAt) - this.toDate(a?.updatedAt))
      .slice(0, 6)
  );

  constructor() {
    console.log('[AdminDashboard] constructor reached');
    console.log('[AdminDashboard] role:', this.sessionService.role());
    this.loadData();
  }

 loadData(): void {
  console.log('[AdminDashboard] loadData started');

  this.loading.set(true);
  this.error.set(null);

  let pendingRequests = 2;

  const finishOne = (): void => {
    pendingRequests--;

    console.log('[AdminDashboard] pending requests:', pendingRequests);

    if (pendingRequests <= 0) {
      this.loading.set(false);
      console.log('[AdminDashboard] loading finished');
    }
  };

  this.crowdfundingService.adminListApplications().pipe(
    timeout(6000),
    catchError((err) => {
      console.error('[AdminDashboard] applications API failed or timed out:', err);
      this.error.set('Could not load applications.');
      return of([]);
    })
  ).subscribe({
    next: (applications) => {
      console.log('[AdminDashboard] raw applications:', applications);
      this.applications.set(this.asArray(applications));
    },
    error: (err) => {
      console.error('[AdminDashboard] applications subscription error:', err);
      this.applications.set([]);
      finishOne();
    },
    complete: () => {
      finishOne();
    }
  });

  this.crowdfundingService.adminListPayments().pipe(
    timeout(6000),
    catchError((err) => {
      console.error('[AdminDashboard] payments API failed or timed out:', err);
      this.error.set('Could not load payments.');
      return of([]);
    })
  ).subscribe({
    next: (payments) => {
      console.log('[AdminDashboard] raw payments:', payments);
      this.payments.set(this.asArray(payments));
    },
    error: (err) => {
      console.error('[AdminDashboard] payments subscription error:', err);
      this.payments.set([]);
      finishOne();
    },
    complete: () => {
      finishOne();
    }
  });
}

  normalize(value: unknown): string {
    return String(value ?? '').trim().toUpperCase();
  }

  beautify(value: unknown): string {
    return String(value ?? 'Unknown')
      .toLowerCase()
      .split('_')
      .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
      .join(' ');
  }

  toDate(value: unknown): number {
    const time = new Date(String(value ?? '')).getTime();
    return Number.isNaN(time) ? 0 : time;
  }

  getPaymentName(item: any): string {
    return (
      item?.campaignBusinessName ||
      item?.businessName ||
      item?.campaignTitle ||
      item?.reference ||
      'Payment'
    );
  }

  private asArray(value: unknown): any[] {
    if (Array.isArray(value)) {
      return value;
    }

    if (value && typeof value === 'object') {
      const maybeContent = (value as any).content;

      if (Array.isArray(maybeContent)) {
        return maybeContent;
      }

      const maybeData = (value as any).data;

      if (Array.isArray(maybeData)) {
        return maybeData;
      }

      const maybeItems = (value as any).items;

      if (Array.isArray(maybeItems)) {
        return maybeItems;
      }
    }

    return [];
  }
}